using Exiled.API.Interfaces;
using System.ComponentModel;

namespace GhostTutorials.Configs
{
    public class Config : IConfig
    {
        public bool IsEnabled { get; set; } = true;
        [Description("Should debug messages be shown?")]
        public bool Debug { get; set; } = false;
        [Description("Command name.")]
        public string CommandName { get; set; } = "ghost";
        [Description("Specify permission you want this command to check.")]
        public string PermissionName { get; set; } = "ghost";
        [Description("Set the description that players will see, when they try to use your command in RA.")]
        public string RaDescription { get; set; } = "Command that makes you Ghost.";
        [Description("What will player see if he will try to use command without permissions.")]
        public string NoPermissionsResponse { get; set; } = "You don't have permissions to use this command.";
        [Description("What will player see if he will try to use command not in spectators.")]
        public string NotSpectatorResponse { get; set; } = "You must be a spectator to use this command.";
        [Description("What will player see if ghost enable was successful.")]
        public string SuccessOnResponse { get; set; } = "Ghost on.";
        [Description("What will player see if ghost disable was successful.")]
        public string SuccessOffResponse { get; set; } = "Ghost off.";
    }
}