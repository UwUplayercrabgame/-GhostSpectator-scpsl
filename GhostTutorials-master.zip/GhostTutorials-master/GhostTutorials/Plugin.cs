﻿using Exiled.API.Features;
using System;
using System.Collections.Generic;
using System.Linq;
using Exiled.API.Extensions;
using Exiled.API.Features.Roles;
using Exiled.Events.EventArgs.Player;
using Exiled.Events.EventArgs.Scp2536;
using Exiled.Events.EventArgs.Server;
using GhostTutorials.Configs;
using PlayerRoles;
using UnityEngine;

namespace GhostTutorials
{
    public class GhostTutorials : Plugin<Config>
    {
        public override string Author => "scp252arc";

        public override string Name => "GhostTutorials";

        public override string Prefix => ".ghost";

        public override Version Version => new Version(1, 0, 0);

        public override Version RequiredExiledVersion => new Version(9, 2, 2);

        public static GhostTutorials Instance;

        public List<Player> Ghosts;
        
        public override void OnEnabled()
        {
            Instance = this;
            
            Ghosts = new List<Player>();
            
            Exiled.Events.Handlers.Player.FlippingCoin += OnFlippingCoin;
            
            Exiled.Events.Handlers.Player.InteractingDoor += OnInteractingDoor;
            Exiled.Events.Handlers.Player.InteractingElevator += OnInteractingElevator;
            Exiled.Events.Handlers.Player.InteractingLocker += OnInteractingLocker;
            Exiled.Events.Handlers.Player.PickingUpItem += OnPickingUpItem;
            Exiled.Events.Handlers.Player.DroppingItem += OnDroppingItem;
            Exiled.Events.Handlers.Player.ItemAdded += OnItemAdded;

            Exiled.Events.Handlers.Scp2536.OpeningGift += OnOpeningGift;

            Exiled.Events.Handlers.Server.SelectingRespawnTeam += OnSelectingRespawnTeam;

            base.OnEnabled();
        }
        public override void OnDisabled()
        {
            Instance = null;
            
            Ghosts?.Clear();
            Ghosts = null;
            
            Exiled.Events.Handlers.Player.FlippingCoin -= OnFlippingCoin;
            
            Exiled.Events.Handlers.Player.InteractingDoor -= OnInteractingDoor;
            Exiled.Events.Handlers.Player.InteractingElevator -= OnInteractingElevator;
            Exiled.Events.Handlers.Player.InteractingLocker -= OnInteractingLocker;
            Exiled.Events.Handlers.Player.PickingUpItem -= OnPickingUpItem;
            Exiled.Events.Handlers.Player.DroppingItem -= OnDroppingItem;
            Exiled.Events.Handlers.Player.ItemAdded -= OnItemAdded;
            
            Exiled.Events.Handlers.Scp2536.OpeningGift -= OnOpeningGift;
            
            Exiled.Events.Handlers.Server.SelectingRespawnTeam -= OnSelectingRespawnTeam;

            base.OnDisabled();
        }
        public void OnFlippingCoin(FlippingCoinEventArgs ev)
        {
            if (ev.Player != null && ev.Player.Role == RoleTypeId.Tutorial && Ghosts.Contains(ev.Player))
            {
                var to = Player.List.Where(x => x.Role != RoleTypeId.Tutorial && x.Role != RoleTypeId.Spectator && x.Role != RoleTypeId.Overwatch && x.Role != RoleTypeId.Filmmaker).GetRandomValue();
                if (to != null)
                {
                    Log.Debug($"Teleported \"{ev.Player.DisplayNickname}\" to \"{to.DisplayNickname}\"");
                    ev.Player.Teleport(to.Position);
                    return;
                }
                Log.Debug($"Player to teleport for \"{ev.Player.DisplayNickname}\" is not found");
            }
        }
        public void OnInteractingDoor(InteractingDoorEventArgs ev)
        {
            if (ev.Player == null || ev.Player.Role != RoleTypeId.Tutorial)
                return;
            
            ev.IsAllowed = !Ghosts.Contains(ev.Player);
        }
        public void OnInteractingElevator(InteractingElevatorEventArgs ev)
        {
            if (ev.Player == null || ev.Player.Role != RoleTypeId.Tutorial)
                return;
            
            ev.IsAllowed = !Ghosts.Contains(ev.Player);
        }
        public void OnInteractingLocker(InteractingLockerEventArgs ev)
        {
            if (ev.Player == null || ev.Player.Role != RoleTypeId.Tutorial)
                return;
            
            ev.IsAllowed = !Ghosts.Contains(ev.Player);
        }
        public void OnPickingUpItem(PickingUpItemEventArgs ev)
        {
            if (ev.Player == null || ev.Player.Role != RoleTypeId.Tutorial)
                return;
            
            ev.IsAllowed = !Ghosts.Contains(ev.Player);
        }
        public void OnDroppingItem(DroppingItemEventArgs ev)
        {
            if (ev.Player == null || ev.Player.Role != RoleTypeId.Tutorial)
                return;
            
            ev.IsAllowed = !Ghosts.Contains(ev.Player);
        }
        public void OnItemAdded(ItemAddedEventArgs ev)
        {
            if (ev.Player == null || ev.Player.Role != RoleTypeId.Tutorial || !Ghosts.Contains(ev.Player))
                return;

            ev.Player.RemoveItem(ev.Item);
        }
        public void OnOpeningGift(OpeningGiftEventArgs ev)
        {
            if (ev.Player == null || ev.Player.Role != RoleTypeId.Tutorial)
                return;
            
            ev.IsAllowed = !Ghosts.Contains(ev.Player);
        }
        public void OnSelectingRespawnTeam(SelectingRespawnTeamEventArgs ev)
        {
            foreach (var player in Ghosts)
            {
                if (player != null && player.Role == RoleTypeId.Tutorial)
                {
                    {
                        Log.Debug($"Ghost mode disabled for \"{player.DisplayNickname}\" - respawning");
                        player.ClearInventory();
                        player.IsGodModeEnabled = false;
                        ((FpcRole)player.Role).IsNoclipEnabled = false;
                        player.SetFakeScale(Vector3.one, Player.List);
                        player.Role.Set(RoleTypeId.Spectator);
                        player.IsMuted = false;
                    }
                }
            }
            Ghosts.Clear();
        }
    }
}
