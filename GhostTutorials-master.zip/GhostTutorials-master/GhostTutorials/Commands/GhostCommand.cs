using System;
using System.Linq;
using CommandSystem;
using Exiled.API.Extensions;
using Exiled.API.Features;
using Exiled.API.Features.Roles;
using Exiled.Permissions.Extensions;
using PlayerRoles;
using UnityEngine;
using MEC;

namespace GhostTutorials.Commands
{

    [CommandHandler(typeof(RemoteAdminCommandHandler))]
    [CommandHandler(typeof(ClientCommandHandler))]
    public class GhostCommand : ICommand
    {
        public string Command { get; } = GhostTutorials.Instance.Config.CommandName;
        
        public string[] Aliases { get; } = new[] { "ghost" };
        
        public string Description { get; } = GhostTutorials.Instance.Config.RaDescription;

        public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
        {
            if (!sender.CheckPermission(GhostTutorials.Instance.Config.PermissionName))
            {
                response = GhostTutorials.Instance.Config.NoPermissionsResponse;
                return false;
            }

            var player = Player.Get(sender);
            
            if (player.Role == RoleTypeId.Tutorial && GhostTutorials.Instance.Ghosts.Contains(player))
            {
                Log.Debug($"Ghost mode disabled for \"{player.DisplayNickname}\"");
                
                player.ClearInventory();
                
                player.Role.Set(RoleTypeId.Spectator);
                player.IsGodModeEnabled = false;
                player.SetFakeScale(Vector3.one, Player.List.Where(x => x != player));
                player.IsMuted = false;
                
                GhostTutorials.Instance.Ghosts.Remove(player);
                
                response = GhostTutorials.Instance.Config.SuccessOffResponse;
                return true;
            }

            if (player.Role != RoleTypeId.Spectator)
            {
                response = GhostTutorials.Instance.Config.NotSpectatorResponse;
                return false;
            }
            
            Log.Debug($"Ghost mode enabled for \"{player.DisplayNickname}\"");
            player.Role.Set(RoleTypeId.Tutorial);
            player.IsGodModeEnabled = true;
            ((FpcRole)player.Role).IsNoclipEnabled = true;
            
            Timing.CallDelayed(0.1f, () =>
            {
                if (!Round.IsStarted)
                    return;
                
                player.Teleport(RoleTypeId.Tutorial.GetRandomSpawnLocation());
            });
            
            player.SetFakeScale(new Vector3(0.01f, 0.01f, 0.01f), Player.List.Where(x => x != player));
            player.IsMuted = true;
            
            player.AddItem(ItemType.Coin);

            GhostTutorials.Instance.Ghosts.Add(player);
            
            response = GhostTutorials.Instance.Config.SuccessOnResponse;
            return true;
        }
    }
}